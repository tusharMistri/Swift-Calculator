//
//  calculator.swift
//  test
//
//  Created by Tushar on 22/12/17.
//  Copyright © 2017 tushar. All rights reserved.
//

import UIKit

class calculator: UIViewController {
    
    //MARK:- Outlets
    
    var strOperationValues = String()
    var str_buttonClick = String()
    
    @IBOutlet var textfieldOutput: UITextField!
    
    
    //MARK:- ViewLIfeCycle
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
    }
    
    //MARK:- Button Action Methods
    
    @IBAction func buttonClick_Number(_ sender: UIButton)
    {
        
         textfieldOutput.text = textfieldOutput.text! + (sender.titleLabel?.text)!
        
    }
    
    @IBAction func buttonClick_Clear(_ sender: UIButton)
    {
        textfieldOutput.text = ""
    }
    
    @IBAction func buttonClick_Operation(_ sender: UIButton)
    {
        
        if sender.titleLabel?.text == "+"
        {
            str_buttonClick = "+"
            strOperationValues = textfieldOutput.text!
            textfieldOutput.text = ""
        }
        else if sender.titleLabel?.text == "-"
        {
            str_buttonClick = "-"
            strOperationValues = textfieldOutput.text!
            textfieldOutput.text = ""

        }
        else if sender.titleLabel?.text == "*"
        {
            str_buttonClick = "*"
            strOperationValues = textfieldOutput.text!
            textfieldOutput.text = ""
        }
        else if sender.titleLabel?.text == "/"
        {
            str_buttonClick = "/"
            strOperationValues = textfieldOutput.text!
            textfieldOutput.text = ""
        }
    }
    
    @IBAction func buttonClick_eqal(_ sender: UIButton)
    {
        
        if str_buttonClick == "+"
        {
            textfieldOutput.text = String(Int(textfieldOutput.text!)! + Int(strOperationValues)!)
        }
        else if str_buttonClick == "-"
        {
            if Int(strOperationValues)! > Int((textfieldOutput.text!))!
            {
                textfieldOutput.text = String(Int(strOperationValues)! - Int((textfieldOutput.text!))!)
            }
            else
            {
                textfieldOutput.text = String(Int(strOperationValues)! - Int((textfieldOutput.text!))!)
            }
        }
        else if str_buttonClick == "*"
        {
            textfieldOutput.text = String(Int(textfieldOutput.text!)! * Int(strOperationValues)!)
        }
        else if str_buttonClick == "/"
        {
            textfieldOutput.text = String(Int(strOperationValues)! / Int(textfieldOutput.text!)!)
        }
        
    }
    
    
    //MARK:- Extra Methods
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    

}
