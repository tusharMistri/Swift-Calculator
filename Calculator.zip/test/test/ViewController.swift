//
//  ViewController.swift
//  test
//
//  Created by Tushar on 17/12/17.
//  Copyright © 2017 tushar. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    // su karvu che action banavi che k outhlaet banvo che , outlet
    
    
    @IBOutlet var btn: UIButton!
    
    var Dic1 = NSMutableDictionary()
    
    let str = String()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        let str = "hiee i remember!"
        
        let index = str.index(str.startIndex, offsetBy: 2)
        let str_range = str.substring(to: index)
        print("range of \(str_range)")
        
        let new_range = str.substring(to:(str.index(str.startIndex, offsetBy:5)))
        
        print("new_range :\(new_range)")
        
        print("str :\(str.appending("string new"))")
        
        print("str :\(str.appending("string new"))")
        
        

        var dicDetail1 = NSMutableDictionary()
        var dicDetail2 = NSMutableDictionary()
        var arryDetail = NSMutableArray()
        dicDetail1 = ["Activity id" : 1 , "Activity Name" : "ABC"]
        dicDetail2 = ["Activity id" : 2 , "Activity Name" : "XYZ"]
        arryDetail.add(dicDetail1)
        arryDetail.add(dicDetail2)
        Dic1 = ["Activity lis" : arryDetail]
        print("\(Dic1)")
        
        
        let ActivityName = ((Dic1.value(forKey: "Activity lis") as! NSMutableArray ).object(at: 0) as! NSMutableDictionary).value(forKey: "Activity Name") as! String
        print("ActivityName :\(ActivityName)")
        
     
        // means k string no (0,5) ni string tamney maley emaj ney ? ok
        
        //done ???, are you there ?, wait, ok   oyyyyyyyyyyyyyy uper tame lakhyu tu>? me to atyare joyu,hahahaha, mane khanar j nai yr sache ,nmanep khabar e navigation na uper aave pela data pass thay pachi navigate thay,ha pachi j navigation thai pela data pass karvano,ha mare jate karvu tu yr thodu thodu khabar hati,ha pan thai to gayu tamney khabar to nati ,pan ave yad aavi gayu me niche je line lakhi e jate lakhi sache mane khabar j nai tame uper lakhelu che,ha pan barobar lakhiyu che havey ey line tamarey navogation thai ey pela lakhi nakhvani,ha saru chalo vandho nai,,  ru n karo,ha
        
    }
    
    
    @IBAction func btnCllick(_ sender: Any)
    {
        let firstVc = self.storyboard?.instantiateViewController(withIdentifier: "FirstViewController") as! FirstViewController
        firstVc.dic_passData = Dic1
        self.navigationController?.pushViewController(firstVc, animated: true)
    
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }

}

