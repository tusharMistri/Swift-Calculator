//
//  FirstViewController.swift
//  test
//
//  Created by Tushar on 20/12/17.
//  Copyright © 2017 tushar. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController,UITableViewDelegate,UITableViewDataSource
{
    
@IBOutlet var btlForData: UITableView!


    var dic_passData = NSMutableDictionary()
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        btlForData.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        print("dic_passData : \(self.dic_passData)")
        
        // one minute ha , ha , start kariey ?, ?????? ,ha,ok, calculator j karvu ch eny ek kai biju sikhvanu che ? ,cal j, ,ok jo pela maru assignment batavi dav, jo aa che, ha jovu,ha , aa tupple etley ? ,wait jo kav, ha,index wise value print karava khabar padi?,ha,thai gayu,done chalo havey aapdey start kariey, ha,ok, tamaru assignment kaley joe laav hu atiyarey cal patavi daiey ? ,ha kale ghare cho to joi lejo,, ha saru ,password ne e khabar ne?,ha mobile no.,ha,ok , barobar ?, point vadi vlaue mate?,ha ey lai laiey ,ha,
        
        
        
        
        var pt : (Int,Int) = (20,10)
        print(pt.0)
        print(pt.1)
        
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return (self.dic_passData.value(forKey: "Activity lis") as! NSMutableArray ).count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as UITableViewCell
     cell.textLabel?.text = ((self.dic_passData.value(forKey: "Activity lis") as! NSMutableArray ).object(at: indexPath.row) as! NSMutableDictionary).value(forKey: "Activity Name") as? String
        return cell
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
       
    }
}
